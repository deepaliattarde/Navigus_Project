package navigus;
public class Navigus {
    public static void main(String[] args) {
        // Set the home screen
        Home h=new Home();
        h.setVisible(true);
    }
}
